# Passo a Passo

1 - Mude o título do arquivo .html para "Exercício 05" (sem as aspas)

2 - Olhe a imagem de layout.png para saber como o seu layout precisa ficar no final do exercício

3 - Reset todo o css

4 - Inclua um bloco no seu html coloque a cor de fundo "rebeccapurple" (sem as aspas), largura de 1000px, uma altura minima de 100px, padding para todos os lados em 10px e coloque ela no centro da página, use o arquivo styles.css que esta dentro da pasta css.

5 - Dentro do bloco anterior, você vai inluir outros 8 blocos, um do lado do outro (enquanto tiver espaço), ou seja, 2 linhas com 4 blocos, cada um dos blocos com uma tag img, h3 e paragrafo(exatamente nessa ordem), também coloque ele com o a cor de fundo "grey", margem para direita de 20px e uma margem para baixo de 20px, use o arquivo styles.css que esta dentro da pasta css.

6 - Nas tag img incluia a imagem gatinho.jpg com uma largura de 225px e uma altura de 225px.

7 - Nas tag h3 coloque elas centralizadas, com a familia de font sans-serif, com todas as letras maíusculas e a cor branca.

8 - Nas tag de parágrafos, coloque um padding de 10px para todos os lados, o tamnho da fonte em 14px e as cores brancas.

9 - Olhe a imagem de layout.png para saber se seu layout está igual a imagem

## Se você concluiu todos os passo, você concluiu o desafio! \o/ Parabéns!

### Obs. Os textos dos blocos:

Sir Harry Swanson
Você não pode possuir um gato. O melhor que você pode fazer é ser parceiro.

Nise da Silveira
O gato é um ser essencialmente livre e essa liberdade desafia o homem.