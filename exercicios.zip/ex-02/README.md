# Passo a Passo

1 - Mude o título do arquivo .html para "Exercício 02" (sem as aspas)

2 - Olhe a imagem de layout.png para saber como o seu layout precisa ficar no final do exercício

3 - Crie 6 tags do h1 até o h6 com o texto de "h1" até o "h6" (sem as aspas), Olhe a imagem de layout.png em caso de dúvidas.

4 - Crie uma lista não ordenada com 5 itens

5 - Crie uma lista ordenada com 5 itens

6 - Crie um link, que abra em uma nova página, com o texto "globo.com" (sem as aspas) e que leve para o "https://www.globo.com/"(sem as aspas)

7 - Olhe em outro navegador diferente do chrome, internet explore, por exemplo, se o caracteres especiais estão funcionando, se não estiver, conserte.
Alguns caracteres especiais: ç â à á ã ê é è í ì î ô

8 - Olhe a imagem de layout.png para saber se seu layout está igual a imagem

## Se você concluiu todos os passo, você concluiu o desafio! \o/ Parabéns!
