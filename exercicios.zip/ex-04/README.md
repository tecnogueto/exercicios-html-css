# Passo a Passo

1 - Mude o título do arquivo .html para "Exercício 04" (sem as aspas)

2 - Olhe a imagem de layout.png para saber como o seu layout precisa ficar no final do exercício

3 - Reset todo o css

4 - Inclua uma tag de imagem no seu html, coloque a imagem gatinho.jpg que esta dentro da pasta img, dê a imagem uma largura de 225px, uma altura de 225px, uma borda de 5px solida e vermelha, e uma margem para a direita de 20px, use o arquivo styles.css que esta dentro da pasta css.

5 - Adicione um parágrafo e coloque esse parágrafo no lado direito da imagem do gatinho, use o arquivo styles.css que esta dentro da pasta css.

6 - Adicione um link que abra em uma nova aba com o texto "Veja mais imagens de gatinhos" (sem as aspas), com o link "http://twixar.me/bbvK" (sem as aspas) e com uma margin de 15px para cima.

7 - Olhe a imagem de layout.png para saber se seu layout está igual a imagem

## Se você concluiu todos os passo, você concluiu o desafio! \o/ Parabéns!

### Obs. O texto do parágrafo

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi eu nibh et purus mollis maximus. Maecenas rutrum nulla blandit, viverra neque ac, gravida turpis. Phasellus euismod dapibus turpis, sed interdum nulla congue in. Pellentesque aliquam consectetur bibendum. Cras at tincidunt mauris. Aenean hendrerit dui ut porta aliquam. In hac habitasse platea dictumst. Aliquam non convallis quam. Etiam auctor, est id ultricies dictum, tortor felis consequat purus, in mollis velit leo quis nisi. Nulla luctus facilisis ornare. Vivamus hendrerit sagittis eros in tincidunt. Donec bibendum erat sit amet tellus condimentum viverra. Duis quis dui ut mauris maximus luctus vitae ac felis. Mauris tempor nulla libero. Duis sagittis lorem a erat tempus posuere. Praesent ut mollis sem. Pellentesque volutpat pretium orci vitae ornare. Etiam at imperdiet tortor. Quisque nec commodo elit. Aenean laoreet, ligula ut luctus convallis, purus enim finibus lacus, nec varius lectus quam vel metus.
