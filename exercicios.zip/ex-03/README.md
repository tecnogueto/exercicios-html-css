# Passo a Passo

1 - Mude o título do arquivo .html para "Exercício 03" (sem as aspas)

2 - Olhe a imagem de layout.png para saber como o seu layout precisa ficar no final do exercício

3 - Reset todo o css

4 - Crie um título com h1 e com o texto "Fontes e cores" e coloque uma margem de 30px para baixo, use o arquivo styles.css que esta dentro da pasta css.

5 - Crie uma tag hr e coloque uma margem de 30px para baixo, use o arquivo styles.css que esta dentro da pasta css.

6 - Crie 5 blocos, e dentro de cada um coloque um h3 e um parágrafo e altere os tamanhos, cores (use as cores, green, red, blue), tranformação(todas as letras em maiúsculas) e decoração dos textos de acordo com a imagem de layout.png, use o arquivo styles.css que esta dentro da pasta css.

7 - Olhe a imagem de layout.png para saber se seu layout está igual a imagem

## Se você concluiu todos os passo, você concluiu o desafio! \o/ Parabéns!

### Obs. Os textos dos blocos:

Portuguesa com Catupiry
Presunto, ovo, ervilha, cebola, catupiry e azeitona preta

Pepperoni
Pepperoni e cebola

Parmegiana
Carpaccio de berinjela, molho de tomate especial e queijo parmesão

Frango com Catupiry
Frango, catupiry e milho

Coco Bambu Especial
Salmão, espinafre, alcaparras, tomate seco e manjericão
