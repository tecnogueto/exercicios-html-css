# Passo a Passo

1 - Mude o título do arquivo .html para "Exercício 01" (sem as aspas)

2 - Olhe a imagem de layout.png para saber como o seu layout precisa ficar no final do exercício

3 - Crie um título h1 com o texto "Exercício 01" (sem as aspas)

4 - Coloque o texto no centro da página, use o arquivo styles.css que esta dentro da pasta css.
 
5 - Crie 4 blocos, e dentro de cada um coloque um h3 e um paragrafo.

6 - Olhe a imagem de layout.png para saber se seu layout está igual a imagem

## Se você concluiu todos os passo, você concluiu o desafio! \o/ Parabéns!

### Obs. Os textos dos blocos:

Tilápia Coco Bambu - R$ 60,49

Filé de Tilápia grelhado sobre camadas de batata inglesa, coberto com delicioso molho agridoce de mostarda, cebola, alcaparras, tomate, estragão e salsinha. Molho servido a temperatura ambiente. Acompanha arroz branco.

Peixe Pizzaiolo - R$ 80,99

Filé de peixe em cubos, à dorê. Servidos sobre espaguete ao alho e óleo. Coberto com molho de tomate e molho branco, numa perfeita combinação. Gratinados com queijo muçarela e orégano.

Peixe c/ Crosta de Pão- R$ 40,99

Filet de peixe com crosta crocante de pão, acompanha talharim à alho e óleo, e legumes.

Peixe à Dorê - R$ 90,99

Filé de Tilápia grelhado sobre camadas de batata inglesa, coberto com delicioso molho agridoce de mostarda, cebola, alcaparras, tomate, estragão e salsinha. Molho servido a temperatura ambiente. Acompanha arroz branco.


